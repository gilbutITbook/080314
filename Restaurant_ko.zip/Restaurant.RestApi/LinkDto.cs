/* Copyright (c) Mark Seemann 2020. All rights reserved. */
﻿namespace Ploeh.Samples.Restaurants.RestApi
{
    public sealed class LinkDto
    {
        public string? Rel { get; set; }
        public string? Href { get; set; }
    }
}