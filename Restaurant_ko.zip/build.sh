#!/usr/bin/env bash
dotnet test Build.sln --configuration Release
